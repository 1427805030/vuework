<template>
    <div class="sass">
        <p class="red">sass 红色字体</p>
        <p class="blue">sass 蓝色字体</p>
    </div>
</template>
<style lang="scss">
    .sass {
        .red {
            color: red
        }
    }
</style>
<script>
    require("../css/sass-example.scss")
</script>
