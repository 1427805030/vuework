<template>
    <div>
        <p class="red">红色字体</p>
        <p class="blue">蓝色字体</p>
    </div>
</template>
<style>
    .red {
        color: red
    }
</style>
<script>
    require("../css/style.css")
</script>


