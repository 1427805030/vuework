<template>
    <div>
        <img src="../images/logo.png">
        <br>
        背景图片
        <div class="bg"></div>
    </div>
</template>
<style scoped>
    img{
        width: 100px;
    }
    .bg {
        width: 100%;
        height: 300px;
        background: url("../images/logo.png");
        background-size: 50px;
    }
</style>
