<template>
    <div class="async">
        这是一个异步组件
    </div>
</template>
<style lang="less">
    .async {
        color: red
    }
</style>
