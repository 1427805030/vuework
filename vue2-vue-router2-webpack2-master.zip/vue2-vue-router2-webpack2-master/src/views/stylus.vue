<template>
    <div class="stylus">
        <p class="red">stylus 红色字体</p>
        <p class="blue">stylus 蓝色字体</p>
    </div>
</template>
<style lang="stylus">
    .stylus
        .red
            color red
</style>
<script>
    require("../css/stylus-example.styl")
</script>
