<template>
    <div>
        <i class="iconfont icon-appreciate"></i>
        <i class="iconfont icon-check"></i>
        <i class="iconfont icon-close"></i>
        <i class="iconfont icon-edit"></i>
        <i class="iconfont icon-emoji"></i>
        <i class="iconfont icon-favorfill"></i>
        <i class="iconfont icon-favor"></i>
        <i class="iconfont icon-loading"></i>
    </div>
</template>
<style scoped>

    .iconfont {
        font-size: 50px;
        color: #20744A;
    }

</style>
<script>
    require("../css/font/iconfont.css")
</script>
