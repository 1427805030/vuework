<template>
    <div class="less">
        <p class="red">less 红色字体</p>
        <p class="blue">less 蓝色字体</p>
    </div>
</template>
<style lang="less">
    .less .red {
        color: red
    }
</style>
<script>
    require("../css/less-example.less")
</script>
